<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class add_image_to_products_table extends Controller
{
    //
}